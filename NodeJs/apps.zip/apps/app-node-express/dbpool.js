const mysql = require('mysql');
const util   = require('util');

var pool = mysql.createPool({
    connectionLimit: 10,
    host: '127.0.0.1',
    user: 'root',
    password: 'rpass2019',
    database: 'desarrollo'
})

pool.getConnection((err, connection) => {
    if (err) {
        if (err.code === 'PROTOCOL_CONNECTION_LOST') {
            console.error('Conexion a la base de datos cerrada.')
        }
        if (err.code === 'ER_CON_COUNT_ERROR') {
            console.error('La base de datos no tiene conexiones disponibles.')
        }
        
        if (err.code === 'ECONNREFUSED') {
            console.error('La base de datos rechazo la conexión.')
        }
    }    if (connection) connection.release()    
    return;
});

// Promisify for Node.js async/await.
pool.query = util.promisify(pool.query)

module.exports = pool;