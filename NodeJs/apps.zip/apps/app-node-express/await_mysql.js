//npm install util
const util   = require('util');
const mysql  = require('mysql');
var express = require('express');	
var bodyParser = require('body-parser');

//const config = require('./configs/config');
var dbpool = require('./dbpool.js');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
//-----------------------------------------------------------------------------
app.get('/', function (req, res) {

	fnExecuteQuery().then(result => {
    	
    	let sRowDatos = "";
    	
    	//console.log(result); //42
    	res.statusCode = 200;
		res.setHeader('Content-Type', 'text/html; charset=utf-8');	

		res.write('<html>');
		res.write('<body><table><thead><tr>');
		res.write('<th>iid</th>');
		res.write('<th>nombre</th>');
		res.write('<th>activo ?</th>');
		res.write('</tr>');		
		res.write('<tbody>');		

		result.forEach(element => { 
  			//console.log(element); 
  			sRowDatos += "<tr>";
  			sRowDatos += "<td>"+ element.iidpais +"</td>\n<td>" + element.cnombre + "</td>\n<td>" + element.lactivo + "</td>";
  			sRowDatos += "</tr>";
		}); 

		res.write(sRowDatos);		
		res.write('</tbody>');		
		
		res.write('</body>');
		res.write('</html>');
		res.end();    	
    	//return res.estatus send({ error: true, message: 'hello' });
    	//return res.json(result);
	});	
	//return res.send({ error: true, message: 'hello' });
});
//-----------------------------------------------------------------------------
async function fnExecuteQuery() {
    //return "sucess";
    var sSqlQuery = 'SELECT iidpais, cclave, cnombre, lactivo FROM pais';
    const res = await dbpool.query(sSqlQuery);  	
  	return res;
}//fin: 
//-----------------------------------------------------------------------------
//Iniciar el servidor
app.listen(3000, function () {
 	console.log('Node app is running on port 3000');
});
//-----------------------------------------------------------------------------
