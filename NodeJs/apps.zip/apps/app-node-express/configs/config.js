module.exports = {    
    configdb : {
    	host: '127.0.0.1',
    	port:3306,
    	user: 'root',
    	password: 'rpass2019',
    	database: 'desarrollo'
 	}
}