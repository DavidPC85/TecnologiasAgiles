var express = require('express');

var erouter = express.Router();

erouter.use(function timeLog(req, res, next) {
 	console.log('Timestamp actual: ', Date.now());
 	next();
});

// define the home page route
erouter.get('/', function(req, res) {
  	res.send('pagina principal routing');
});

// define the about route
erouter.get('/about', function(req, res) {
  	res.send('Acerca routing');
});

module.exports = erouter;