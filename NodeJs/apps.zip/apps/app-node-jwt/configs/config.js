module.exports = {
    CLAVE_SECRETA: "C1av3-53cr37a*",
    EXPIRE_TOKEN : 120
}