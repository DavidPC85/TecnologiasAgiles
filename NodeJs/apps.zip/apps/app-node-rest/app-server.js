	//Incluidos requeridos
	var express    = require('express');	
	var bodyParser = require('body-parser');
	var mysql 	   = require('mysql');

	var app = express();

	app.use(bodyParser.json());

	app.use(bodyParser.urlencoded({ extended: true }));

	// default route
	app.get('/', function (req, res) {
		return res.send({ error: true, message: 'hello' })
	});
	
	// connection configurations
 	var dbConn = mysql.createConnection({
    	host: '127.0.0.1',
    	port:3306,
    	user: 'root',
    	password: 'rpass2019',
    	database: 'desarrollo'
 	});

 	// connect to database
 	dbConn.connect(); 
 	//---------------------------------------------------------------------------------------------
 	//Callbacks para procesamiento de datos
 	//GET Paises
 	app.get('/api/pais/:idpais?', function (req, res) {

 		//var sQuerySelect = "select iidpais, cclave, cnombre, dtcreacion, lactivo from pais"; 
 		var sQuerySelect = "select iidpais, cclave, cnombre from pais @where"; 
 	
 		if(req.params.idpais === null || req.params.idpais == undefined ){
 			sQuerySelect = sQuerySelect.replace(/@where/g, " where lactivo = 1");
 		}//fin:if
 		else{
 			sQuerySelect = sQuerySelect.replace(/@where/g, " where iidpais =" + req.params.idpais);
 		}//fin:else
 		
    	dbConn.query(
    		sQuerySelect, 
    		function (error, results, fields) {
        		if (error) throw error;    
        		res.setHeader('Content-Type', 'application/json');
        		return res.status(200).send(
        			{ 
         				lError: false, 
         				cError:"",
         				aPaises: results
         			}        			
        		);         		
     		}
     	);
 	});
 	//---------------------------------------------------------------------------------------------
 	//POST PAISES
	app.post('/api/pais', function (req, res) {
	    
	    var sSqlInsert = "INSERT INTO pais (cclave, cnombre, dtcreacion, lactivo) VALUES(";
	    
	    var oPais = req.body;
	   
	    res.setHeader('Content-Type', 'application/json');
	    if(oPais.hasOwnProperty("cclave")  && oPais.hasOwnProperty("cnombre")){
	    	sSqlInsert += "'" + oPais.cclave  + "', ";
		    sSqlInsert += "'" + oPais.cnombre + "', ";
		    sSqlInsert += " CURRENT_TIMESTAMP,";
		    sSqlInsert += " 1 )";

		    dbConn.beginTransaction(function(errTran) {
		    	if (errTran) { throw errTran; }

		    	dbConn.query(sSqlInsert, function (error, results, fields) {	   	
		   			if (error) {		   				
		   				dbConn.rollback(function() {
					        throw error;
					    });
		   			}//fin:if

		   			dbConn.commit(function(){});

		    		return res.status(201).send(
		    			{ 
		    				lError: false, 
		    				cError: "",
		    				iidpais: results.insertId
		    			}
		    		);
		    	});//fin:dbConn.query
		    });//fin:beginTran		 
	    }//fin:if
	    else{
	    	return res.status(400).send(
	       		{ 
	       			lError:true,
	       			cError: 'No se enviaron informacion del pais para realizar el alta.' 
	       		}
	       	);
	    }//fin:else		  
	});//fin:post
 	//---------------------------------------------------------------------------------------------
 	//PUT PAISES
 	app.put('/api/pais/:idpais?', function (req, res) {
		
		var sSQLUpdate = "UPDATE pais set @values where iidpais = @idpais";
		var sSetValues = "";

		var oPais = req.body;

		if(req.params.idpais === null || req.params.idpais == undefined ){
			return res.status(400).send(
	       		{ 
	       			lError:true,
	       			cError: 'No fue enviado el identificador del pais a modificar.' 
	       		}
	       	);
		}//fin:if
		else{
			if(oPais.hasOwnProperty("cclave") || oPais.hasOwnProperty("cnombre") 
				|| oPais.hasOwnProperty("lactivo")){

				if(oPais.hasOwnProperty("cclave")){
					sSetValues += " cclave ='" + oPais.cclave + "'";
				}//fin:if
				
				if(oPais.hasOwnProperty("cnombre")){
					if(sSetValues != "" ) sSetValues += ", ";
					sSetValues += " cnombre ='" + oPais.cnombre + "'";
				}//fin:if

				if(oPais.hasOwnProperty("lactivo")){
					if(sSetValues != "" ) sSetValues += ", ";
					sSetValues += " lactivo = " + oPais.lactivo;
				}//fin:if	   

				sSQLUpdate = sSQLUpdate.replace(/@values/g, sSetValues);
				sSQLUpdate = sSQLUpdate.replace(/@idpais/g, req.params.idpais);

				dbConn.beginTransaction(function(errTran) {
			    	if (errTran) { throw errTran; }

			    	dbConn.query(sSQLUpdate, function (error, results, fields) {
				   		if (error) {		   				
			   				dbConn.rollback(function() {
						        throw error;
						    });
			   			}//fin:if
			   			
			   			dbConn.commit(function(){});

				    	return res.status(200).send(
				    		{ 
				    			lError: false, 
				    			cError: "",
				    			cMensaje: "Registro actualizado correctamente."		    			
				    		}
				    	);
			    	});//fin:dbConn.query			    
			    });//fin:beginTran							
		    }//fin:if
		    else{
		    	return res.status(400).send(
		       		{ 
		       			lError:true,
		       			cError: 'No fueron enviados datos para la actualización.' 
		       		}
		       	);
		    }//fin:else	
		}//fin:else		
	});//fin:put
 	//--------------------------------------------------------------------------------------------- 
 	//DELETE
	app.delete('/api/pais/:idpais?', function (req, res) {		

		if(req.params.idpais === null || req.params.idpais == undefined ){
			return res.status(400).send(
	       		{ 
	       			lError:true,
	       			cError: 'No fue enviado el identificador del pais a eliminar.' 
	       		}
	       	);
		}//fin:if
		else{

			dbConn.beginTransaction(function(errTran) {
			    if (errTran) { throw errTran; }

			    dbConn.query(
					'DELETE FROM pais WHERE iidpais = ?', 
					req.params.idpais, 
					function (error, results, fields) {		        		
		        		if (error) {		   				
			   				dbConn.rollback(function() {
						        throw error;
						    });
			   			}//fin:if
			   			
			   			dbConn.commit(function(){});

		        		return res.send(
		        			{ 
		        				lError: false, 
				    			cError: "",
				    			cMensaje: "Registro eliminado correctamente."	
		        			}
		        		);			
					}
				);//fin:dbConn.query
			});//fin:begin:trans
		}//fin:else	   
	});//fin:delete 
 	//--------------------------------------------------------------------------------------------- 	 	
 	//Iniciar el servidor
	app.listen(3002, function () {
	 	console.log('Node app is running on port 3002');
	});
	//---------------------------------------------------------------------------------------------
 	//module.exports = app;