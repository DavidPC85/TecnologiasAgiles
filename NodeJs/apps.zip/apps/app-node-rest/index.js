var mysql = require('mysql');

var conexion = mysql.createConnection({
	host:'127.0.0.1',
	port:3306,
	user:'root',
	password:'rpass2018',
	database:'desarrollo'
});

conexion.connect(function (error){
	//console.log(error);
	if (error){
		console.log('Problemas de conexion con mysql');
	}
	else{
		console.log('coneccion success');
	}
});
