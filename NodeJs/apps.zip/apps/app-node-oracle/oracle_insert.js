const oracledb = require('oracledb');
const dbConfig = require('./configs/dbconfig.js');

async function run() {

    let connection;

    try {
        
        connection = await oracledb.getConnection(dbConfig);    
        
        //INSERT INTO DESARROLLO.PAIS(IIDPAIS, dtcreacion,lactivo, cclave, cnombre)
        // VALUES (DESARROLLO.SEQ_ID_PAIS.nextval, SYSDATE, 1,'ZW', 'Zimbabue');
        /*
        let result = await connection.execute(
            `INSERT INTO DESARROLLO.PAIS(IIDPAIS, lactivo, cclave, cnombre) VALUES (:id, :nm)`, 
            { 
                id : {val: 1 }, 
                nm : {val: 'Chris'} 
            }
        );
        console.log("Rows inserted: " + result.rowsAffected);
        */
        let result = await connection.execute(
            `INSERT INTO DESARROLLO.PAIS(IIDPAIS, lactivo, cclave, cnombre) VALUES (DESARROLLO.SEQ_ID_PAIS.nextval, :lactivo, :cclave, :cnombre)`,
            { 
                lactivo :   {val: 1 }, 
                cclave :    {val: 'TEX'},
                cnombre:    {val: 'PAIS TEST'}
            },
            { autoCommit: true }
        );
        console.log("Rows inserted: " + result.rowsAffected);
   
        /*
        let result = await connection.execute(
            `INSERT INTO DESARROLLO.PAIS(IIDPAIS, lactivo, cclave, cnombre) VALUES (DESARROLLO.SEQ_ID_PAIS.nextval, :lactivo, :cclave, :cnombre)`,
            [1, 'XYZ', 'PAIS EJEMPLO'],
            { autoCommit: true }
        );
        console.log("Rows inserted: " + result.rowsAffected);
        */

        /*
        //Ejemplo de UPDATE        
        let result = await connection.execute(
            `UPDATE DESARROLLO.PAIS SET cnombre = :nombre WHERE IIDPAIS = :id`,
            ['OTRO NOMBRE', 157],
            { autoCommit: true }
        );
        console.log("Rows updated: " + result.rowsAffected); 
        */
    } 
    catch (err) {
        console.error(err);
    } 
    finally {
        if (connection) {
            try {
                await connection.close();
            } 
            catch (err) {
                console.error(err);
            }
        }
    }
}//fin:run
//-----------------------------------------------------------------------------
//Iniciar la ejecucion del script
run();
//-----------------------------------------------------------------------------