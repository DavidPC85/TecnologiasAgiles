module.exports = {
    
    user : process.env.NODE_ORACLEDB_USER || "DESARROLLO",
    password : "dev2019",

    //connectString : process.env.NODE_ORACLEDB_CONNECTIONSTRING || "localhost/orclpdb",
    connectString : process.env.NODE_ORACLEDB_CONNECTIONSTRING || "127.0.0.1/XE",

    externalAuth  : process.env.NODE_ORACLEDB_EXTERNALAUTH ? true : false
};