    //npm install express --save
    //npm install oracledb

    const oracledb = require('oracledb');
    const dbConfig = require('./configs/dbconfig.js');
    
    var sSqlQuery = 
        "SELECT IIDPAIS, CCLAVE, CNOMBRE, LACTIVO FROM DESARROLLO.PAIS WHERE IIDPAIS = :id"

    oracledb.getConnection(
        { 
            user          : dbConfig.user,
            password      : dbConfig.password,
            connectString : dbConfig.connectString
        },
        function(err, connection) {
            if (err) {
                console.error(err.message);
                return;
            }            
            connection.execute(                        
                sSqlQuery,
                [156],// bind value :id
                { 
                    maxRows: 1        
                },    
                function(err, result) {
                    if (err) {
                        console.error(err.message);
                        doRelease(connection);
                        return;
                    }//fin:if
                    //Imprimir las columnas del query
                    //console.log(result.metaData); 

                    //Imprimir los resultados
                    console.log(result.rows);     
                    //Finalizamos la coneccion
                    doRelease(connection);
                }   
            );
        }
    );//fin:oracledb.getConnection
    //-------------------------------------------------------------------------
    //Cerrar la coneccion de oracle
    function doRelease(connection) {

        connection.close(
            function(err) {
            if (err) {
                console.error(err.message);
            }
        });
    }//fin:doRelease
    //-------------------------------------------------------------------------